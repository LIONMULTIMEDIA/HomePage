"use strict";

(() => {
  const config = window.LION_SITE_CONFIG || {};
  const menuToggle = document.getElementById("menu-toggle");
  const navigation = document.getElementById("site-nav");
  const setMenu = (isOpen) => {
    navigation.classList.toggle("is-open", isOpen);
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "關閉導覽選單" : "開啟導覽選單");
  };
  menuToggle.addEventListener("click", () => setMenu(menuToggle.getAttribute("aria-expanded") !== "true"));
  navigation.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => setMenu(false)));
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && menuToggle.getAttribute("aria-expanded") === "true") {
      setMenu(false);
      menuToggle.focus();
    }
  });
  window.matchMedia("(min-width: 621px)").addEventListener("change", (event) => {
    if (event.matches) setMenu(false);
  });

  const rows = [...document.querySelectorAll("#business-rows tr")];
  const filters = [...document.querySelectorAll("[data-filter]")];
  const search = document.getElementById("business-search");
  let selectedCategory = "all";
  function applyFilter() {
    const query = search.value.trim().toLocaleLowerCase();
    let visibleCount = 0;
    rows.forEach((row) => {
      const matchesCategory = selectedCategory === "all" || row.dataset.category === selectedCategory;
      const matchesQuery = row.textContent.toLocaleLowerCase().includes(query);
      row.hidden = !(matchesCategory && matchesQuery);
      if (!row.hidden) visibleCount += 1;
    });
    filters.forEach((button) => {
      const isSelected = button.dataset.filter === selectedCategory;
      button.classList.toggle("is-active", isSelected);
      button.setAttribute("aria-pressed", String(isSelected));
    });
    document.getElementById("result-count").textContent = `顯示 ${visibleCount} 項，共 ${rows.length} 項`;
    document.getElementById("empty-state").hidden = visibleCount !== 0;
  }
  filters.forEach((button) => button.addEventListener("click", () => {
    selectedCategory = button.dataset.filter;
    applyFilter();
  }));
  search.addEventListener("input", applyFilter);
  document.getElementById("reset-search").addEventListener("click", () => {
    selectedCategory = "all";
    search.value = "";
    applyFilter();
    search.focus();
  });

  document.getElementById("copy-business").addEventListener("click", async () => {
    const text = rows.map((row) => `${row.cells[0].textContent.trim()} ${row.cells[1].textContent.trim()}`).join("\n");
    const status = document.getElementById("copy-status");
    try {
      if (!navigator.clipboard || !window.isSecureContext) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(text);
      status.textContent = `已複製全部 ${rows.length} 項營業項目。`;
    } catch {
      status.textContent = "瀏覽器未允許複製，請直接選取表格中的文字。";
    }
  });

  const email = typeof config.email === "string" ? config.email.trim() : "";
  if (/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email)) {
    const href = `mailto:${encodeURIComponent(email).replace(/%40/g, "@")}`;
    const contact = document.getElementById("contact-email");
    contact.href = href;
    contact.hidden = false;
    document.getElementById("contact-pending").hidden = true;
    document.getElementById("company-note").hidden = true;
    const field = document.getElementById("company-email");
    const link = document.createElement("a");
    link.href = href;
    link.textContent = email;
    field.replaceChildren(link);
    field.classList.remove("pending-value");
  }
  for (const [key, fieldName] of [["phone", "phone"], ["address", "address"], ["taxId", "tax"]]) {
    const value = typeof config[key] === "string" ? config[key].trim() : "";
    if (value) {
      document.getElementById(`company-${fieldName}`).textContent = value;
      document.getElementById(`company-${fieldName}-row`).hidden = false;
    }
  }
  document.getElementById("preview-note").hidden = config.preview === false;
  if (email) document.querySelector(".preview-note-detail").textContent = "公司形象網站";
  document.getElementById("year").textContent = String(new Date().getFullYear());

  if ("IntersectionObserver" in window) {
    const links = [...navigation.querySelectorAll("a")];
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        links.forEach((link) => {
          if (link.getAttribute("href") === `#${entry.target.id}`) link.setAttribute("aria-current", "location");
          else link.removeAttribute("aria-current");
        });
      });
    }, { rootMargin: "-15% 0px -65% 0px", threshold: 0 });
    document.querySelectorAll("main section[id]").forEach((section) => observer.observe(section));
  }
})();
